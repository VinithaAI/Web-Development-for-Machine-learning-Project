from django.db import models

# Create your models here.
class ckdModel(models.Model):

    concave_points_mean=models.FloatField()
    radius_worst=models.FloatField()
    perimeter_worst=models.FloatField()
    area_worst=models.FloatField()
    concave_points_worst=models.FloatField()
