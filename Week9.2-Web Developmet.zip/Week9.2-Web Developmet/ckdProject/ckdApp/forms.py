from django import forms
from .models import *


class ckdForm(forms.ModelForm):
    class Meta():
        model=ckdModel
        fields=['concave_points_mean', 'radius_worst', 'perimeter_worst', 'area_worst', 'concave_points_worst']
