from django.apps import AppConfig


class CkdappConfig(AppConfig):
    name = 'ckdApp'
